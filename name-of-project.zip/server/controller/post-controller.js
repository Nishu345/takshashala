
   import post from '../model/post.js';


  export const create = async (request, response) =>{
      try{ 
    const post = await new post( request.body);
      post.save();

      return response.status(200.).json('Post saved successfully');
      } catch(error){
          return response.status(500).json(error);
      }
 }

 export const getAllPosts = async (request, response) =>{
    let category = request.query.category;
     let posts;
  try{
      if(category){
        posts = await Post.find({categories: category})
      } else{ 
       posts =  await Post.find({ })
      }
       return response.status(200).json(posts);
  } catch (error){
    return response.status(500).json({msg: error.message})
  }
 }


    export const getPoat = async ( request, response) =>{
      try{
        
          const post = await Post.findById(request.params.id);
      
           return response.status(200).json(post);
      }catch(error){
        return response.status(500).json({ msg: error . message })
      }
    }
    export const updatePost = async (request, response) => {
      try {
      const post = await post.findById(request.params.id);

      if (!post) {
        return response.status(404).json({ msg: 'post notb found'});
      }

      await post.findByIdAndUpdate(request.param.id,{$set: request.body }) // $set, #addToset
      return response.status(200).json({ msg: 'post update successfully'})
      }catch (error) {
      return response.status(500).json({ erroe: error.message})
      }
    }

    export const deletePost = async (request, response) => {
      try {
        const post = await post.findById(request,params.id);
        if (!post) {
          return response.status(404).json({ msg: 'post not found'})
        }
        await post.delete();
        return response.status(200).json({ msg: 'post deleted successfully'});
      } catch (error) {
       return response.status(500).json({ error: error.message})
      }
    }